=== TITLE ANIMATOR ===
Contributors: Arkaprava Majumder,Amit Saha
Tags: title, title rotator, title animator, title tag
Requires at least: 2.8
Tested up to: 3.8.1
Stable tag: trunk
License: GPL or later

Animate your website title with five different effects, lightweighted & easy installation.

== Description ==
Animate your website title with five different effects, lightweighted & easy installation.


Demo:

* http://www.pilgrimsholidays.com
* http://www.ebangali.co.in

A quicklook into Title Animator.

  * 5 different Effects (Type-Writer, Blink, Marquee, Spilt Vertical In, Slide InOut) .
  * Lightweight.
  * Easy Installation.
  * Optimized Code.
  
Change Effects From Settings--> Title Animator
 
 
Developed By : 

Arkaprava Majumder (http://arkapravamajumder.com)

Amit Saha (http://developeramit.com)

== Installation ==

1. Download Title Animator.
2. Upload to your site,(/wp-content/plugins/) or Go Dasboard-->Plugins-->Add New-->search with "Title Animator"-->install.
3. Activate it.


You're done!

Uninstalling is as simple as deactivating the plugin.

== Screenshots ==

1. screenshot-1.gif

== Frequently Asked Questions ==

None yet, if you have one post it at http://arkapravamajumder.com 
or, Fb me Arkaprava majumder (http://fb.com/arkaindas)
or, Tweet me (http://twitter.com/arkaindas)

== Change Log ==
= Version 1.0 =



= Requirements =

    WordPress 2.8+
    PHP 5+ 

= Feedback =

We would like to receive your feedback and suggestions. You may send me mail at hello@arkapravamajumder.com.